/** IMPORT JS FILE */
ek.require("ao.ajax.Ajax");
ek.require("ao.ajax.AjaxManager");
/** REGISTER PACKAGE */
ek.register("ao.ajax.*");