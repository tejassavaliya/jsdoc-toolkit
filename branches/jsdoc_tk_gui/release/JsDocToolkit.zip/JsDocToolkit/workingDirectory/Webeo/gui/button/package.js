/** IMPORT JS FILE */
ek.require("gui.button.Button");
ek.require("gui.button.ToggleButtonManager");
/** REGISTER PACKAGE */
ek.register("gui.button.*");

