/** IMPORT JS FILE */
ek.require("gui.event.ShortCut");
ek.require("gui.event.KeyListener");
/** REGISTER PACKAGE */
ek.register("gui.event.*");

