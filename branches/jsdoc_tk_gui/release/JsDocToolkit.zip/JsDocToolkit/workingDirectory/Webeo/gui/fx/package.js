/** IMPORT JS FILE */
ek.require("gui.fx.Fade");
/** REGISTER PACKAGE */
ek.register("gui.fx.*");

