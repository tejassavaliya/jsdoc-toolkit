/** IMPORT JS FILE */
ek.require("gui.layout.TabbedPane");
ek.require("gui.layout.Bar");
ek.require("gui.layout.ToolBar");

/** REGISTER PACKAGE */
ek.register("gui.layout.*");

