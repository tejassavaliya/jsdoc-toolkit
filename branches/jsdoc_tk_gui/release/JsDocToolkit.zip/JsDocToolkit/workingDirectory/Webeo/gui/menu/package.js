/** IMPORT SUB PACKAGE*/
ek.require("gui.menu.Menu");

/** REGISTER PACKAGE */
ek.register("gui.menu.*");

