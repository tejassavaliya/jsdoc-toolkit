/** IMPORT SUB PACKAGE*/
ek.require("gui.table.Table");
/** REGISTER PACKAGE */
ek.register("gui.table.*");

