/** IMPORT JS FILE */
ek.require("gui.tooltip.TooltipTemplate");
ek.require("gui.tooltip.Tooltip");
ek.require("gui.tooltip.TooltipManager");
/** REGISTER PACKAGE */
ek.register("gui.tooltip.*");

