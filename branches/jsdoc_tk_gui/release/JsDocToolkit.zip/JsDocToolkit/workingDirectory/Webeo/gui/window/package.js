/** IMPORT JS FILES */
ek.require("gui.window.Wait");
/** REGISTER PACKAGE */
ek.register("gui.window.*");

